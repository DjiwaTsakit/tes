#!/usr/bin/env bash
# install.sh — instalasi dependency toolkit
# Jalankan di mesin Anda sendiri (butuh Go >=1.21 dan Python >=3.10 + internet)

set -e

echo "[*] Mengecek Go..."
if ! command -v go &> /dev/null; then
    echo "[!] Go belum terinstall. Install dulu dari https://go.dev/dl/"
    exit 1
fi

echo "[*] Install ProjectDiscovery suite..."
go install -v github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest
go install -v github.com/projectdiscovery/httpx/cmd/httpx@latest
go install -v github.com/projectdiscovery/katana/cmd/katana@latest

echo "[*] Install URL collectors..."
go install github.com/lc/gau/v2/cmd/gau@latest
go install github.com/tomnomnom/waybackurls@latest
go install github.com/jaeles-project/gospider@latest

echo "[*] Install filtering & utility tools..."
go install github.com/tomnomnom/gf@latest
go install github.com/tomnomnom/qsreplace@latest
go install github.com/s0md3v/uro@latest 2>/dev/null || pip install uro --break-system-packages
go install github.com/Emoe/kxss@latest

echo "[*] Install dalfox (XSS scanner utama)..."
go install github.com/hahwul/dalfox/v2@latest

echo "[*] Setup gf patterns (termasuk pattern xss)..."
mkdir -p ~/.gf
git clone https://github.com/1ndianl33t/Gf-Patterns.git /tmp/gf-patterns 2>/dev/null || true
cp /tmp/gf-patterns/*.json ~/.gf/ 2>/dev/null || echo "[!] Gagal copy gf patterns, cek manual"

echo "[*] Install Arjun (hidden parameter discovery)..."
pip install arjun --break-system-packages

echo "[*] Install Python deps + Playwright..."
pip install -r requirements.txt --break-system-packages
python3 -m playwright install chromium

echo "[*] Install interactsh-client (untuk blind XSS callback)..."
go install github.com/projectdiscovery/interactsh/cmd/interactsh-client@latest

echo ""
echo "[✓] Instalasi selesai. Pastikan \$GOPATH/bin ada di \$PATH kamu:"
echo '    export PATH=$PATH:$(go env GOPATH)/bin'
echo ""
echo "Lanjut: cp config.example.yaml config.yaml, lalu isi scope.txt"
