#!/usr/bin/env python3
"""
verify_execution.py — Lapisan verifikasi akhir untuk kandidat reflected/DOM
XSS. Scanner seperti dalfox/XSStrike kadang menandai sesuatu "vulnerable"
padahal cuma reflect di tempat yang tidak tereksekusi (mis. di dalam
komentar HTML, atau di-escape parsial). Script ini membuka ulang tiap URL
dengan browser sungguhan dan mengonfirmasi:
  1. Native dialog (alert/confirm/prompt) benar-benar muncul, ATAU
  2. Marker DOM (window flag) benar-benar ter-set oleh payload.

Input: file JSON berisi list URL kandidat (hasil parsing dari dalfox_reflected.json
atau dalfox_dom.json).

Usage:
    python3 verify_execution.py --candidates dalfox_reflected.json \
        --output verified_reflected.json --screenshot-dir output/screenshots
"""

import argparse
import json
import re
import uuid
from pathlib import Path

from playwright.sync_api import sync_playwright

MARKER_PREFIX = "vfymark"


def load_dalfox_urls(path: str):
    """Parse output JSON dalfox (format bisa berupa list of finding object)."""
    data = json.loads(Path(path).read_text())
    urls = []
    if isinstance(data, list):
        for item in data:
            u = item.get("data") or item.get("url") or item.get("poc")
            if u:
                urls.append(u)
    return list(set(urls))


def inject_marker_payload(url: str, token: str) -> str:
    """Ganti placeholder umum atau tambahkan payload marker ke URL kalau
    dalfox belum menyertakan payload lengkap di URL PoC-nya."""
    marker_script = f"<script>window.{MARKER_PREFIX}_{token}=true</script>"
    if "XSSMARKER" in url:
        return url.replace("XSSMARKER", marker_script)
    return url  # asumsikan dalfox sudah menyertakan payload lengkap di PoC URL


def verify_url(playwright, url: str, token: str, timeout_ms: int, screenshot_dir: Path):
    entry = {"url": url, "status": "unknown", "detail": "", "dialog_triggered": False}
    dialog_messages = []

    browser = playwright.chromium.launch(headless=True)
    context = browser.new_context(ignore_https_errors=True)
    page = context.new_page()
    page.set_default_timeout(timeout_ms)

    def on_dialog(dialog):
        dialog_messages.append(dialog.message)
        dialog.dismiss()

    page.on("dialog", on_dialog)

    try:
        page.goto(url, wait_until="networkidle")
        page.wait_for_timeout(1500)

        window_flag = False
        try:
            window_flag = page.evaluate(f"window.{MARKER_PREFIX}_{token} === true")
        except Exception:
            pass

        entry["dialog_triggered"] = len(dialog_messages) > 0
        entry["window_flag"] = window_flag

        if entry["dialog_triggered"] or window_flag:
            entry["status"] = "CONFIRMED"
            entry["detail"] = (
                f"Dialog triggered: {dialog_messages}" if dialog_messages
                else "Window flag berhasil ter-set oleh payload"
            )
            shot_path = screenshot_dir / f"confirmed_{token}.png"
            page.screenshot(path=str(shot_path), full_page=True)
            entry["screenshot"] = str(shot_path)
        else:
            entry["status"] = "UNCONFIRMED"
            entry["detail"] = "Tidak ada eksekusi terdeteksi saat direplay di browser nyata"

    except Exception as e:
        entry["status"] = "error"
        entry["detail"] = str(e)
    finally:
        browser.close()

    return entry


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--candidates", required=True,
                     help="File JSON hasil dalfox (reflected atau DOM)")
    ap.add_argument("--output", required=True)
    ap.add_argument("--timeout-ms", type=int, default=15000)
    ap.add_argument("--screenshot-dir", default="output/screenshots")
    args = ap.parse_args()

    urls = load_dalfox_urls(args.candidates)
    screenshot_dir = Path(args.screenshot_dir)
    screenshot_dir.mkdir(parents=True, exist_ok=True)

    print(f"[*] Memverifikasi {len(urls)} kandidat dengan headless browser...")

    results = []
    with sync_playwright() as p:
        for url in urls:
            token = uuid.uuid4().hex[:8]
            target_url = inject_marker_payload(url, token)
            res = verify_url(p, target_url, token, args.timeout_ms, screenshot_dir)
            print(f"    [{res['status']}] {url}")
            results.append(res)

    Path(args.output).write_text(json.dumps(results, indent=2))
    confirmed = sum(1 for r in results if r["status"] == "CONFIRMED")
    print(f"[✓] {confirmed}/{len(results)} kandidat terkonfirmasi eksekusi nyata → {args.output}")


if __name__ == "__main__":
    main()
