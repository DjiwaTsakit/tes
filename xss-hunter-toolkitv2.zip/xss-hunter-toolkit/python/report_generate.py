#!/usr/bin/env python3
"""
report_generate.py — Gabungkan semua hasil (reflected, DOM, stored, blind)
jadi satu laporan HTML yang bisa langsung dilampirkan ke laporan bug bounty.

Usage:
    python3 report_generate.py --output-dir output/ --report output/report.html
"""

import argparse
import json
from pathlib import Path
from datetime import datetime

TEMPLATE = """<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>XSS Hunting Report</title>
<style>
  body {{ font-family: -apple-system, Segoe UI, Roboto, sans-serif; margin: 2rem; background:#0f1117; color:#e6e6e6; }}
  h1 {{ color:#ff5f5f; }}
  h2 {{ border-bottom: 2px solid #333; padding-bottom: 6px; margin-top: 2.5rem; }}
  table {{ width:100%; border-collapse: collapse; margin-top: 1rem; }}
  th, td {{ text-align:left; padding: 8px 10px; border-bottom: 1px solid #2a2d3a; font-size: 14px; }}
  th {{ background:#1a1d29; }}
  .VULNERABLE, .CONFIRMED {{ color:#ff5f5f; font-weight:bold; }}
  .SUSPECTED {{ color:#ffb454; font-weight:bold; }}
  .SAFE, .UNCONFIRMED {{ color:#7ee787; }}
  .meta {{ color:#888; font-size: 13px; }}
  .summary {{ display:flex; gap: 1.5rem; margin: 1.5rem 0; }}
  .card {{ background:#1a1d29; padding: 1rem 1.5rem; border-radius: 8px; }}
  .card .num {{ font-size: 28px; font-weight:bold; }}
  a {{ color:#79c0ff; }}
</style>
</head>
<body>
<h1>🕷️ XSS Hunting Report</h1>
<p class="meta">Generated: {timestamp}</p>

<div class="summary">
  <div class="card"><div class="num">{n_confirmed}</div>Terkonfirmasi (Reflected/DOM)</div>
  <div class="card"><div class="num">{n_stored}</div>Stored XSS Rentan</div>
  <div class="card"><div class="num">{n_blind}</div>Blind XSS Terinject (pending callback)</div>
</div>

<h2>Reflected / DOM XSS — Terverifikasi</h2>
{confirmed_table}

<h2>Stored XSS</h2>
{stored_table}

<h2>Blind XSS — Payload Terinject (cek interactsh untuk callback)</h2>
{blind_table}

</body>
</html>
"""


def build_table(rows, columns):
    if not rows:
        return "<p class='meta'>Tidak ada data.</p>"
    head = "".join(f"<th>{c}</th>" for c in columns)
    body_rows = []
    for r in rows:
        cells = "".join(f"<td class='{r.get('status','')}'>{r.get(c, '')}</td>"
                         if c == "status" else f"<td>{r.get(c, '')}</td>"
                         for c in columns)
        body_rows.append(f"<tr>{cells}</tr>")
    return f"<table><tr>{head}</tr>{''.join(body_rows)}</table>"


def safe_load(path: Path):
    if path.exists():
        try:
            return json.loads(path.read_text())
        except Exception:
            return []
    return []


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--output-dir", required=True)
    ap.add_argument("--report", required=True)
    args = ap.parse_args()

    outdir = Path(args.output_dir)

    confirmed = safe_load(outdir / "verified_reflected.json") + \
        safe_load(outdir / "verified_dom.json")
    stored = safe_load(outdir / "stored_results.json")
    blind_map = safe_load(outdir / "blind_map.json")
    blind_rows = [{"token": k, **v} for k, v in blind_map.items()] if isinstance(blind_map, dict) else []

    confirmed_table = build_table(
        [r for r in confirmed if r.get("status") == "CONFIRMED"],
        ["url", "status", "detail", "screenshot"]
    )
    stored_table = build_table(
        [r for r in stored if r.get("status") in ("VULNERABLE", "SUSPECTED")],
        ["name", "output_url", "status", "detail", "screenshot"]
    )
    blind_table = build_table(
        blind_rows, ["token", "type", "url", "parameter"]
    )

    html = TEMPLATE.format(
        timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        n_confirmed=sum(1 for r in confirmed if r.get("status") == "CONFIRMED"),
        n_stored=sum(1 for r in stored if r.get("status") == "VULNERABLE"),
        n_blind=len(blind_rows),
        confirmed_table=confirmed_table,
        stored_table=stored_table,
        blind_table=blind_table,
    )

    Path(args.report).write_text(html)
    print(f"[✓] Laporan HTML tersimpan di {args.report}")


if __name__ == "__main__":
    main()


