# XSS Hunter Toolkit

Automation pipeline untuk pencarian XSS (Reflected, Stored, DOM-based, Blind)
yang menggabungkan tools recon/crawling populer dengan lapisan verifikasi
headless browser untuk mengurangi false positive.

## ⚠️ DISCLAIMER — WAJIB DIBACA

Toolkit ini **hanya boleh digunakan** terhadap target yang:
1. Memiliki program bug bounty resmi dengan scope yang jelas, ATAU
2. Aset milik Anda sendiri / yang Anda punya izin tertulis untuk diuji.

Setiap request otomatis di pipeline ini akan **dicek dulu terhadap `scope.txt`**
sebelum dieksekusi (lihat `modules/00_scope_check.sh`). Jangan hapus/lewati
pengecekan ini. Melanggar scope program bug bounty bisa berujung ban akun
platform (HackerOne/Bugcrowd/Intigriti) bahkan tuntutan hukum.

Toolkit ini TIDAK melakukan exploitation lanjutan (session hijacking, cookie
stealing ke server pihak lain, dsb) — hanya deteksi & bukti eksekusi payload
non-destruktif (alert/marker DOM), sesuai standar proof-of-concept bug bounty.

## Arsitektur Pipeline

```
00_scope_check.sh   → filter semua domain sesuai scope.txt
01_recon.sh         → subfinder + httpx (live hosts)
02_crawl.sh         → katana + gau + waybackurls + gospider (URL collection)
03_param_discovery.sh → Arjun (hidden parameter discovery)
04_filter_candidates.sh → gf 'xss' + qsreplace (kandidat parameter)
05_reflected_scan.sh → kxss + dalfox (reflected XSS)
06_dom_scan.sh       → dalfox --deep-domxss (DOM XSS)

python/blind_inject.py       → inject payload blind XSS (Interactsh) ke semua
                                 parameter & header, untuk stored/blind XSS
                                 yang baru "meledak" nanti (admin panel dsb)
python/stored_xss_hunter.py  → submit payload ke form, revisit halaman output,
                                 pakai Playwright untuk cek marker
python/verify_execution.py   → headless verification: buka ulang semua kandidat,
                                 konfirmasi eksekusi nyata (dialog event / DOM
                                 mutation), screenshot sebagai bukti
python/report_generate.py    → gabungkan semua hasil jadi 1 laporan HTML
```

## Prasyarat Tools (install manual / via install.sh)

| Tool | Fungsi |
|---|---|
| subfinder, httpx, katana | ProjectDiscovery suite (recon & crawl) |
| gau, waybackurls | Historical URL collection |
| gospider | Crawler tambahan |
| Arjun | Hidden parameter discovery |
| gf (+ pattern xss) | URL/parameter filtering |
| qsreplace, uro | Query string manipulation & dedup |
| kxss | Reflection checker cepat |
| dalfox | Scanner XSS utama (reflected + DOM) |
| Python 3.10+, Playwright | Verifikasi headless & stored XSS |
| interactsh-client (opsional) | Callback server untuk blind XSS |

Jalankan `./install.sh` untuk mencoba instalasi otomatis (butuh Go & internet
di mesin Anda — sandbox ini tidak punya akses ke domain-domain tersebut).

## Cara Pakai

```bash
cp config.example.yaml config.yaml
# edit config.yaml: isi domain target & path scope.txt

echo "*.target.com" > scope.txt   # sesuaikan dengan scope program bug bounty

./run_pipeline.sh
```

Hasil akhir ada di `output/report.html`.
