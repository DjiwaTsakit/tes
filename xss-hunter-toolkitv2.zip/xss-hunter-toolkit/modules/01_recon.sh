#!/usr/bin/env bash
# 01_recon.sh — subdomain enumeration + live host detection
#
# Usage: ./01_recon.sh <domain> <output_dir>

set -euo pipefail

DOMAIN="$1"
OUTDIR="$2"
mkdir -p "$OUTDIR"

echo "[*] Subdomain enumeration untuk $DOMAIN ..."
subfinder -d "$DOMAIN" -silent -all > "$OUTDIR/subdomains_raw.txt"

# Selalu masukkan domain utama juga
echo "$DOMAIN" >> "$OUTDIR/subdomains_raw.txt"
sort -u "$OUTDIR/subdomains_raw.txt" -o "$OUTDIR/subdomains.txt"

TOTAL=$(wc -l < "$OUTDIR/subdomains.txt")
echo "[✓] Ditemukan $TOTAL subdomain unik"

echo "[*] Mengecek host yang live..."
cat "$OUTDIR/subdomains.txt" | httpx -silent -follow-redirects -title -status-code \
    -tech-detect -o "$OUTDIR/live_hosts_full.txt"

# Simpan versi bersih (URL saja) untuk dipakai tahap berikutnya
cat "$OUTDIR/live_hosts_full.txt" | awk '{print $1}' > "$OUTDIR/live_hosts.txt"

LIVE=$(wc -l < "$OUTDIR/live_hosts.txt")
echo "[✓] $LIVE host live dari $TOTAL subdomain → $OUTDIR/live_hosts.txt"
