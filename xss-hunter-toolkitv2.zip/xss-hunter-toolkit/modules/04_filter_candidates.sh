#!/usr/bin/env bash
# 04_filter_candidates.sh — filter URL berparameter yang berpotensi XSS
#
# Usage: ./04_filter_candidates.sh <all_urls_file> <output_dir>

set -euo pipefail

ALL_URLS="$1"
OUTDIR="$2"
mkdir -p "$OUTDIR"

echo "[*] Filtering URL dengan gf pattern 'xss'..."
if command -v gf &> /dev/null; then
    cat "$ALL_URLS" | gf xss | sort -u > "$OUTDIR/candidates_gf.txt"
else
    echo "[!] gf tidak ditemukan, skip — pakai heuristik manual (URL berparameter)"
    grep '=' "$ALL_URLS" | sort -u > "$OUTDIR/candidates_gf.txt"
fi

# Fallback tambahan: semua URL yang punya query string, in case gf pattern
# terlalu ketat dan melewatkan sesuatu
grep '?' "$ALL_URLS" | grep '=' | sort -u > "$OUTDIR/candidates_all_params.txt"

cat "$OUTDIR/candidates_gf.txt" "$OUTDIR/candidates_all_params.txt" | \
    sort -u > "$OUTDIR/candidates_merged.txt"

echo "[*] Standarisasi payload marker dengan qsreplace..."
cat "$OUTDIR/candidates_merged.txt" | qsreplace 'XSSMARKER' > "$OUTDIR/candidates_marked.txt"

TOTAL=$(wc -l < "$OUTDIR/candidates_merged.txt")
echo "[✓] $TOTAL URL kandidat siap discan → $OUTDIR/candidates_merged.txt"
