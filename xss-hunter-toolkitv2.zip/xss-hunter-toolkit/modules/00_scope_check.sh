#!/usr/bin/env bash
# 00_scope_check.sh — filter list URL/domain agar hanya yang ada di scope.txt
#
# Usage: ./00_scope_check.sh <input_file> <scope_file> <output_file>
#
# scope.txt berisi pattern per baris, contoh:
#   *.target.com
#   api.target.com
#   -excluded.target.com     <- awalan "-" berarti EXCLUDE (out of scope)

set -euo pipefail

INPUT_FILE="$1"
SCOPE_FILE="$2"
OUTPUT_FILE="$3"

if [[ ! -f "$SCOPE_FILE" ]]; then
    echo "[!] scope.txt tidak ditemukan: $SCOPE_FILE"
    exit 1
fi

TMP_INCLUDE=$(mktemp)
TMP_EXCLUDE=$(mktemp)

# Pisahkan pattern include vs exclude
grep -v '^-' "$SCOPE_FILE" | grep -v '^\s*$' > "$TMP_INCLUDE" || true
grep '^-' "$SCOPE_FILE" | sed 's/^-//' > "$TMP_EXCLUDE" || true

> "$OUTPUT_FILE"

while IFS= read -r url; do
    host=$(echo "$url" | sed -E 's#^[a-zA-Z]+://##' | cut -d'/' -f1 | cut -d':' -f1)
    in_scope=false

    while IFS= read -r pattern; do
        [[ -z "$pattern" ]] && continue
        regex=$(echo "$pattern" | sed 's/\./\\./g; s/\*/.*/g')
        if [[ "$host" =~ ^${regex}$ ]]; then
            in_scope=true
            break
        fi
    done < "$TMP_INCLUDE"

    if [[ "$in_scope" == true ]]; then
        while IFS= read -r expattern; do
            [[ -z "$expattern" ]] && continue
            exregex=$(echo "$expattern" | sed 's/\./\\./g; s/\*/.*/g')
            if [[ "$host" =~ ^${exregex}$ ]]; then
                in_scope=false
                break
            fi
        done < "$TMP_EXCLUDE"
    fi

    if [[ "$in_scope" == true ]]; then
        echo "$url" >> "$OUTPUT_FILE"
    fi
done < "$INPUT_FILE"

rm -f "$TMP_INCLUDE" "$TMP_EXCLUDE"

total_in=$(wc -l < "$INPUT_FILE")
total_out=$(wc -l < "$OUTPUT_FILE")
echo "[✓] Scope check selesai: $total_out / $total_in URL masuk scope → $OUTPUT_FILE"
