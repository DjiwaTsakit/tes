#!/usr/bin/env bash
# 05_reflected_scan.sh — deteksi & scan reflected XSS
#
# Usage: ./05_reflected_scan.sh <candidates_file> <output_dir> <threads>

set -euo pipefail

CANDIDATES="$1"
OUTDIR="$2"
THREADS="${3:-20}"
mkdir -p "$OUTDIR"

echo "[*] [1/2] kxss — quick reflection check..."
if command -v kxss &> /dev/null; then
    cat "$CANDIDATES" | kxss > "$OUTDIR/reflected_raw.txt" 2>/dev/null || true
    REFLECTED=$(wc -l < "$OUTDIR/reflected_raw.txt" 2>/dev/null || echo 0)
    echo "[✓] $REFLECTED parameter menunjukkan reflection"
else
    echo "[!] kxss tidak ditemukan, lanjut langsung ke dalfox"
    cp "$CANDIDATES" "$OUTDIR/reflected_raw.txt"
fi

echo "[*] [2/2] dalfox — full reflected XSS scan (pipe mode)..."
cat "$CANDIDATES" | dalfox pipe \
    --silence \
    --skip-bav \
    --worker "$THREADS" \
    --format json \
    -o "$OUTDIR/dalfox_reflected.json" || true

echo "[✓] Hasil reflected XSS lengkap → $OUTDIR/dalfox_reflected.json"
