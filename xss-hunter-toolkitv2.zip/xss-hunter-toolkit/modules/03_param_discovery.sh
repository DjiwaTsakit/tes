#!/usr/bin/env bash
# 03_param_discovery.sh — temukan parameter tersembunyi (GET/POST/JSON)
# yang tidak muncul dari crawling biasa. Penting untuk stored XSS karena
# banyak field input tidak ter-crawl otomatis.
#
# Usage: ./03_param_discovery.sh <live_hosts_file> <output_dir> <threads>

set -euo pipefail

LIVE_HOSTS="$1"
OUTDIR="$2"
THREADS="${3:-20}"
mkdir -p "$OUTDIR"

> "$OUTDIR/hidden_params.txt"

echo "[*] Menjalankan Arjun per endpoint (ini bisa lama, jalan paralel)..."

run_arjun() {
    local url="$1"
    arjun -u "$url" -m GET,POST,JSON -t 10 --stable -oT "$OUTDIR/tmp_arjun_$$.txt" \
        --rate-limit 5 2>/dev/null || true
    if [[ -f "$OUTDIR/tmp_arjun_$$.txt" ]]; then
        cat "$OUTDIR/tmp_arjun_$$.txt" >> "$OUTDIR/hidden_params.txt"
        rm -f "$OUTDIR/tmp_arjun_$$.txt"
    fi
}
export -f run_arjun
export OUTDIR

cat "$LIVE_HOSTS" | xargs -P "$THREADS" -I{} bash -c 'run_arjun "$@"' _ {}

TOTAL=$(wc -l < "$OUTDIR/hidden_params.txt" 2>/dev/null || echo 0)
echo "[✓] $TOTAL parameter tersembunyi ditemukan → $OUTDIR/hidden_params.txt"
echo "[i] Catatan: hasil ini dipakai python/stored_xss_hunter.py untuk uji stored XSS"
