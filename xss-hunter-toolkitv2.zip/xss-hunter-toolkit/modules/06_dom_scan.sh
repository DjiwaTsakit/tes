#!/usr/bin/env bash
# 06_dom_scan.sh — deteksi DOM-based XSS
#
# Usage: ./06_dom_scan.sh <candidates_file> <output_dir> <threads>

set -euo pipefail

CANDIDATES="$1"
OUTDIR="$2"
THREADS="${3:-20}"
mkdir -p "$OUTDIR"

echo "[*] dalfox — DOM XSS scan (headless-based deep scan)..."
cat "$CANDIDATES" | dalfox pipe \
    --deep-domxss \
    --silence \
    --worker "$THREADS" \
    --format json \
    -o "$OUTDIR/dalfox_dom.json" || true

echo "[✓] Hasil DOM XSS → $OUTDIR/dalfox_dom.json"
echo "[i] Untuk analisa sink JS lebih detail (innerHTML, eval, document.write),"
echo "    hasil file JS dari katana bisa diperiksa manual dengan LinkFinder/SecretFinder"
