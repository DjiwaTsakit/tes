#!/usr/bin/env bash
# 02_crawl.sh — deep URL collection (aktif + pasif/historical)
#
# Usage: ./02_crawl.sh <live_hosts_file> <output_dir> <threads>

set -euo pipefail

LIVE_HOSTS="$1"
OUTDIR="$2"
THREADS="${3:-20}"
mkdir -p "$OUTDIR"

echo "[*] [1/4] Katana — active crawling (JS-aware)..."
katana -list "$LIVE_HOSTS" -jc -kf all -c "$THREADS" -d 3 -silent \
    -o "$OUTDIR/urls_katana.txt" || true

echo "[*] [2/4] gau — historical URLs (Wayback, CommonCrawl, OTX, URLScan)..."
cat "$LIVE_HOSTS" | sed 's#https\?://##' | cut -d'/' -f1 | sort -u | \
    gau --threads "$THREADS" --subs > "$OUTDIR/urls_gau.txt" || true

echo "[*] [3/4] waybackurls — Wayback Machine tambahan..."
cat "$LIVE_HOSTS" | sed 's#https\?://##' | cut -d'/' -f1 | sort -u | \
    waybackurls > "$OUTDIR/urls_wayback.txt" || true

echo "[*] [4/4] gospider — crawler tambahan untuk cakupan lebih dalam..."
gospider -S "$LIVE_HOSTS" -c "$THREADS" -d 2 --other-source -q \
    -o "$OUTDIR/gospider_raw" || true
find "$OUTDIR/gospider_raw" -type f -exec cat {} \; 2>/dev/null | \
    grep -oE 'https?://[^ ]+' > "$OUTDIR/urls_gospider.txt" || true

echo "[*] Menggabungkan & dedup semua URL..."
cat "$OUTDIR"/urls_*.txt 2>/dev/null | sort -u > "$OUTDIR/all_urls_raw.txt"

# uro membersihkan URL yang secara fungsional duplikat (mis. beda value param
# tapi struktur sama) supaya scan lebih efisien
if command -v uro &> /dev/null; then
    cat "$OUTDIR/all_urls_raw.txt" | uro > "$OUTDIR/all_urls.txt"
else
    cp "$OUTDIR/all_urls_raw.txt" "$OUTDIR/all_urls.txt"
fi

TOTAL=$(wc -l < "$OUTDIR/all_urls.txt")
echo "[✓] Total $TOTAL URL unik terkumpul → $OUTDIR/all_urls.txt"
