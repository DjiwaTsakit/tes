#!/usr/bin/env bash
# run_pipeline.sh — Orkestrator utama seluruh pipeline XSS hunting
#
# Prasyarat: config.yaml dan scope.txt sudah diisi (lihat README.md)

set -euo pipefail

CONFIG_FILE="${1:-config.yaml}"

if [[ ! -f "$CONFIG_FILE" ]]; then
    echo "[!] $CONFIG_FILE tidak ditemukan. Copy dari config.example.yaml dulu."
    exit 1
fi

# --- Parse config sederhana (tanpa dependency yq) ---
# Urutan penting: (1) buang komentar "# ..." (2) buang "key: " di depan
# (3) trim trailing whitespace (4) baru strip tanda kutip di ujung.
# Kalau strip quotes dilakukan sebelum trim whitespace, quote di akhir tidak
# akan ke-match karena masih ada spasi sisa komentar setelahnya.
get_yaml_val() {
    local pattern="$1"
    local file="$2"
    grep "$pattern" "$file" | head -1 \
        | sed 's/#.*//' \
        | sed -E 's/^[^:]*:[[:space:]]*//' \
        | sed -E 's/[[:space:]]+$//' \
        | sed -E 's/^"(.*)"$/\1/'
}

DOMAIN=$(get_yaml_val 'domain:' "$CONFIG_FILE")
SCOPE_FILE=$(get_yaml_val 'scope_file:' "$CONFIG_FILE")
OUTDIR=$(get_yaml_val 'base_dir:' "$CONFIG_FILE")
THREADS=$(get_yaml_val 'default:' "$CONFIG_FILE")

DOMAIN=${DOMAIN:-example.com}
SCOPE_FILE=${SCOPE_FILE:-scope.txt}
OUTDIR=${OUTDIR:-./output}
THREADS=${THREADS:-20}

mkdir -p "$OUTDIR"
LOG_FILE="$OUTDIR/pipeline.log"

log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') | $1" | tee -a "$LOG_FILE"
}

log "=== XSS Hunting Pipeline dimulai untuk $DOMAIN ==="

if [[ ! -f "$SCOPE_FILE" ]]; then
    log "[!] scope.txt tidak ditemukan di $SCOPE_FILE — WAJIB ADA sebelum lanjut."
    log "    Buat scope.txt berisi pattern domain yang termasuk scope resmi."
    exit 1
fi

# 1. Recon
log "[STAGE 1] Recon..."
bash modules/01_recon.sh "$DOMAIN" "$OUTDIR" 2>&1 | tee -a "$LOG_FILE"

# Scope check langsung setelah recon, sebelum crawling lebih jauh
log "[STAGE 1b] Scope check host hasil recon..."
bash modules/00_scope_check.sh "$OUTDIR/live_hosts.txt" "$SCOPE_FILE" "$OUTDIR/live_hosts_inscope.txt" 2>&1 | tee -a "$LOG_FILE"

# 2. Deep crawling
log "[STAGE 2] Deep crawling..."
bash modules/02_crawl.sh "$OUTDIR/live_hosts_inscope.txt" "$OUTDIR" "$THREADS" 2>&1 | tee -a "$LOG_FILE"

# Scope check lagi untuk semua URL hasil crawl (jaga-jaga ada redirect ke luar scope)
log "[STAGE 2b] Scope check URL hasil crawl..."
bash modules/00_scope_check.sh "$OUTDIR/all_urls.txt" "$SCOPE_FILE" "$OUTDIR/all_urls_inscope.txt" 2>&1 | tee -a "$LOG_FILE"

# 3. Hidden parameter discovery
log "[STAGE 3] Hidden parameter discovery..."
bash modules/03_param_discovery.sh "$OUTDIR/live_hosts_inscope.txt" "$OUTDIR" "$THREADS" 2>&1 | tee -a "$LOG_FILE"

# 4. Filter kandidat
log "[STAGE 4] Filtering kandidat XSS..."
bash modules/04_filter_candidates.sh "$OUTDIR/all_urls_inscope.txt" "$OUTDIR" 2>&1 | tee -a "$LOG_FILE"

# 5. Reflected scan
log "[STAGE 5] Reflected XSS scan..."
bash modules/05_reflected_scan.sh "$OUTDIR/candidates_merged.txt" "$OUTDIR" "$THREADS" 2>&1 | tee -a "$LOG_FILE"

# 6. DOM scan
log "[STAGE 6] DOM XSS scan..."
bash modules/06_dom_scan.sh "$OUTDIR/candidates_merged.txt" "$OUTDIR" "$THREADS" 2>&1 | tee -a "$LOG_FILE"

# 7. Verifikasi headless untuk reflected & DOM
log "[STAGE 7] Verifikasi eksekusi nyata (headless)..."
python3 python/verify_execution.py --candidates "$OUTDIR/dalfox_reflected.json" \
    --output "$OUTDIR/verified_reflected.json" --screenshot-dir "$OUTDIR/screenshots" 2>&1 | tee -a "$LOG_FILE" || true
python3 python/verify_execution.py --candidates "$OUTDIR/dalfox_dom.json" \
    --output "$OUTDIR/verified_dom.json" --screenshot-dir "$OUTDIR/screenshots" 2>&1 | tee -a "$LOG_FILE" || true

log "[STAGE 8] Stored XSS (butuh targets.json manual — lihat README) — SKIP jika belum disiapkan"
if [[ -f "targets.json" ]]; then
    python3 python/stored_xss_hunter.py --targets targets.json \
        --output "$OUTDIR/stored_results.json" --screenshot-dir "$OUTDIR/screenshots" 2>&1 | tee -a "$LOG_FILE" || true
else
    log "    targets.json tidak ditemukan, skip stage stored XSS."
fi

log "[STAGE 9] Blind XSS injection — butuh interactsh-domain, lihat README untuk jalankan manual"
log "    Contoh: python3 python/blind_inject.py --urls $OUTDIR/candidates_merged.txt \\"
log "            --output $OUTDIR/blind_map.json --interactsh-domain <domain-dari-interactsh-client>"

# 10. Generate report
log "[STAGE 10] Generate laporan HTML..."
python3 python/report_generate.py --output-dir "$OUTDIR" --report "$OUTDIR/report.html" 2>&1 | tee -a "$LOG_FILE"

log "=== Pipeline selesai. Laporan: $OUTDIR/report.html ==="
