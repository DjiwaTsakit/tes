#!/usr/bin/env python3
"""
scope_filter.py — Filter cepat untuk menyaring daftar URL/host berdasarkan scope.txt.

Ditulis dalam Python, BUKAN loop bash, karena bash `while read` yang memanggil
sed/cut per baris sangat lambat untuk puluhan ribu baris — bisa memakan waktu
berjam-jam. Python dengan regex ter-compile sekali di awal + caching per-host
bisa menyelesaikan puluhan ribu baris dalam hitungan detik, karena:
  1. Regex pattern di-compile SEKALI di awal (bukan per baris).
  2. Hasil in-scope/out-of-scope di-cache per HOST (bukan dicek ulang untuk
     setiap URL) — biasanya puluhan ribu URL cuma berasal dari puluhan/ratusan
     host unik, jadi ini penghematan besar.

Usage:
    python3 scope_filter.py <input_file> <scope_file> <output_file>
"""

import re
import sys
from pathlib import Path
from urllib.parse import urlparse


def pattern_to_regex(pattern: str) -> "re.Pattern":
    # escape semua karakter regex spesial KECUALI '*', lalu ganti '*' -> '.*'
    escaped = re.escape(pattern).replace(r"\*", ".*")
    return re.compile(f"^{escaped}$", re.IGNORECASE)


def load_scope(scope_file: str):
    includes, excludes = [], []
    for raw_line in Path(scope_file).read_text().splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("-"):
            pat = line[1:].strip()
            if pat:
                excludes.append(pattern_to_regex(pat))
        else:
            includes.append(pattern_to_regex(line))
    return includes, excludes


def extract_host(url: str) -> str:
    candidate = url if "://" in url else f"http://{url}"
    try:
        host = urlparse(candidate).hostname or ""
    except ValueError:
        host = ""
    return host.lower()


def main():
    if len(sys.argv) != 4:
        print("Usage: scope_filter.py <input_file> <scope_file> <output_file>", file=sys.stderr)
        sys.exit(1)

    input_file, scope_file, output_file = sys.argv[1:4]

    if not Path(scope_file).exists():
        print(f"[!] scope file tidak ditemukan: {scope_file}", file=sys.stderr)
        sys.exit(1)

    includes, excludes = load_scope(scope_file)
    if not includes:
        print(f"[!] Tidak ada pattern include valid di {scope_file}", file=sys.stderr)
        sys.exit(1)

    total = 0
    kept = 0
    host_cache = {}
    out_lines = []

    with open(input_file, "r", errors="ignore") as f:
        for raw in f:
            url = raw.strip()
            if not url:
                continue
            total += 1

            host = extract_host(url)
            if host in host_cache:
                in_scope = host_cache[host]
            else:
                in_scope = any(p.match(host) for p in includes)
                if in_scope and excludes:
                    in_scope = not any(p.match(host) for p in excludes)
                host_cache[host] = in_scope

            if in_scope:
                kept += 1
                out_lines.append(url)

    Path(output_file).write_text("\n".join(out_lines) + ("\n" if out_lines else ""))
    print(f"[✓] Scope check selesai: {kept} / {total} URL masuk scope "
          f"({len(host_cache)} host unik dicek) → {output_file}")


if __name__ == "__main__":
    main()
