#!/usr/bin/env bash
# 02_crawl.sh — deep URL collection (aktif + pasif/historical)
#
# Usage: ./02_crawl.sh <live_hosts_file> <output_dir> <threads> [scope_file]
#
# scope_file bersifat opsional TAPI sangat disarankan diisi — kalau ada, URL
# di luar scope (google.com, facebook.com, CDN pihak ketiga, dll yang ikut
# ke-scrape gospider dari link di halaman) langsung dibuang di tahap ini juga,
# bukan cuma nanti pas scope-check terpisah, supaya tahap-tahap berikutnya
# (dedup, filtering, scan) tidak kebebanan data yang jelas tidak akan dites.

set -euo pipefail

LIVE_HOSTS="$1"
OUTDIR="$2"
THREADS="${3:-20}"
SCOPE_FILE="${4:-}"
mkdir -p "$OUTDIR"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Timeout per tool (detik) supaya pipeline tidak pernah menggantung tanpa
# batas kalau salah satu provider (CDX API archive.org, dsb) lambat/hang.
# Sesuaikan lewat env var kalau target punya history sangat besar, mis:
#   CRAWL_TIMEOUT=1800 ./run_pipeline.sh
CRAWL_TIMEOUT="${CRAWL_TIMEOUT:-600}"

# Catatan: pola "cmd || rc=$?" dipakai (bukan "cmd; rc=$?") karena di bawah
# set -e, kalau cmd exit non-zero (mis. kena timeout/124) shell akan langsung
# keluar SEBELUM baris "rc=$?" sempat jalan. Dengan "|| rc=$?", exit code
# non-zero dari cmd "ditangkap" oleh operator || sehingga set -e tidak trigger.

echo "[*] [1/4] Katana — active crawling (JS-aware)... (timeout ${CRAWL_TIMEOUT}s)"
rc=0
timeout "$CRAWL_TIMEOUT" katana -list "$LIVE_HOSTS" -jc -kf all -c "$THREADS" -d 3 -silent \
    -o "$OUTDIR/urls_katana.txt" || rc=$?
[[ $rc -eq 124 ]] && echo "[!] katana timeout setelah ${CRAWL_TIMEOUT}s, lanjut dengan hasil parsial"

echo "[*] [2/4] gau — historical URLs (Wayback, CommonCrawl, OTX, URLScan)... (timeout ${CRAWL_TIMEOUT}s)"
rc=0
cat "$LIVE_HOSTS" | sed 's#https\?://##' | cut -d'/' -f1 | sort -u | \
    timeout "$CRAWL_TIMEOUT" gau --threads "$THREADS" --subs > "$OUTDIR/urls_gau.txt" || rc=$?
[[ $rc -eq 124 ]] && echo "[!] gau timeout setelah ${CRAWL_TIMEOUT}s, lanjut dengan hasil parsial"

echo "[*] [3/4] waybackurls — Wayback Machine tambahan... (timeout ${CRAWL_TIMEOUT}s)"
rc=0
cat "$LIVE_HOSTS" | sed 's#https\?://##' | cut -d'/' -f1 | sort -u | \
    timeout "$CRAWL_TIMEOUT" waybackurls > "$OUTDIR/urls_wayback.txt" || rc=$?
[[ $rc -eq 124 ]] && echo "[!] waybackurls timeout setelah ${CRAWL_TIMEOUT}s, lanjut dengan hasil parsial"

echo "[*] [4/4] gospider — crawler tambahan untuk cakupan lebih dalam... (timeout ${CRAWL_TIMEOUT}s)"
rc=0
timeout "$CRAWL_TIMEOUT" gospider -S "$LIVE_HOSTS" -c "$THREADS" -d 2 --other-source -q \
    -o "$OUTDIR/gospider_raw" || rc=$?
[[ $rc -eq 124 ]] && echo "[!] gospider timeout setelah ${CRAWL_TIMEOUT}s, lanjut dengan hasil parsial"
find "$OUTDIR/gospider_raw" -type f -exec cat {} \; 2>/dev/null | \
    grep -oE 'https?://[^ ]+' > "$OUTDIR/urls_gospider.txt" || true

echo "[*] Menggabungkan semua URL..."
cat "$OUTDIR"/urls_*.txt 2>/dev/null | sort -u > "$OUTDIR/all_urls_combined.txt"
RAW_TOTAL=$(wc -l < "$OUTDIR/all_urls_combined.txt")

echo "[*] [1/2] Membuang file statis (gambar, font, dokumen, arsip, media, installer, dll)..."
echo "    File jenis ini secara praktis tidak pernah jadi vektor XSS, tapi kalau"
echo "    tetap diikutkan cuma memperlambat scope-check/filtering/scan di belakang."
# Daftar dikelompokkan per kategori biar gampang ditambah/dikurangi manual.
# Sengaja TIDAK memasukkan .js/.json/.xml/.css/.php/.asp/.jsp dll karena itu
# justru target utama pencarian XSS (terutama .js untuk DOM sink analysis).
STATIC_EXT_REGEX='\.('
STATIC_EXT_REGEX+='jpe?g|png|gif|bmp|ico|svg|webp|tiff?|heic|heif|avif'          # gambar
STATIC_EXT_REGEX+='|ai|psd|eps|sketch|fig|indd|xd'                              # design/vector
STATIC_EXT_REGEX+='|woff2?|ttf|eot|otf'                                         # font
STATIC_EXT_REGEX+='|pdf|docx?|xlsx?|pptx?|odt|ods|odp|rtf|csv'                  # dokumen
STATIC_EXT_REGEX+='|zip|rar|7z|tar|gz|tgz|bz2|xz|iso'                           # arsip
STATIC_EXT_REGEX+='|dmg|pkg|deb|rpm|msi|exe|apk|jar|war'                        # installer/binary
STATIC_EXT_REGEX+='|mp3|mp4|avi|mov|wmv|flv|webm|wav|ogg|m4a|flac|mkv|3gp'      # media
STATIC_EXT_REGEX+='|swf|torrent|ics|vcf|class|dll|so|map|scss|sass|less'       # lain-lain
STATIC_EXT_REGEX+=')(\?[^/]*)?$'

grc=0
grep -viE "$STATIC_EXT_REGEX" "$OUTDIR/all_urls_combined.txt" > "$OUTDIR/all_urls_no_static.txt" || grc=$?
# grep exit code 1 artinya "tidak ada baris yang lolos filter" — itu hasil sah,
# BUKAN error. Cuma exit code >1 (mis. regex invalid) yang perlu fallback.
if [[ $grc -gt 1 ]]; then
    echo "[!] grep filter gagal (exit $grc), pakai daftar URL tanpa filter statis"
    cp "$OUTDIR/all_urls_combined.txt" "$OUTDIR/all_urls_no_static.txt"
fi

NO_STATIC_TOTAL=$(wc -l < "$OUTDIR/all_urls_no_static.txt")
REMOVED_STATIC=$((RAW_TOTAL - NO_STATIC_TOTAL))
echo "[✓] Buang $REMOVED_STATIC URL file statis ($RAW_TOTAL → $NO_STATIC_TOTAL URL tersisa)"

echo "[*] [2/2] Membuang domain di luar scope (google.com, facebook.com, CDN pihak"
echo "    ketiga, dll yang ikut ke-scrape gospider dari link di halaman)..."
if [[ -n "$SCOPE_FILE" && -f "$SCOPE_FILE" ]]; then
    python3 "$SCRIPT_DIR/../python/scope_filter.py" \
        "$OUTDIR/all_urls_no_static.txt" "$SCOPE_FILE" "$OUTDIR/all_urls_raw.txt"
    OUTSCOPE_TOTAL=$(wc -l < "$OUTDIR/all_urls_raw.txt")
    REMOVED_SCOPE=$((NO_STATIC_TOTAL - OUTSCOPE_TOTAL))
    echo "[✓] Buang $REMOVED_SCOPE URL di luar scope ($NO_STATIC_TOTAL → $OUTSCOPE_TOTAL URL tersisa)"
else
    echo "[!] scope.txt tidak diberikan/ditemukan di sini — dilewati untuk sekarang."
    echo "    (Stage 2b di run_pipeline.sh tetap akan filter scope sebelum tahap scan,"
    echo "    tapi lebih baik scope.txt tersedia dari awal supaya efisien.)"
    cp "$OUTDIR/all_urls_no_static.txt" "$OUTDIR/all_urls_raw.txt"
fi

echo "[*] Dedup URL yang fungsinya sama..."
if command -v uro &> /dev/null; then
    cat "$OUTDIR/all_urls_raw.txt" | uro > "$OUTDIR/all_urls.txt"
else
    cp "$OUTDIR/all_urls_raw.txt" "$OUTDIR/all_urls.txt"
fi

TOTAL=$(wc -l < "$OUTDIR/all_urls.txt")
echo "[✓] Total $TOTAL URL unik terkumpul (sudah difilter statis + scope) → $OUTDIR/all_urls.txt"
