#!/usr/bin/env bash
# 03_param_discovery.sh — temukan parameter tersembunyi (GET/POST/JSON)
# yang tidak muncul dari crawling biasa. Penting untuk stored XSS karena
# banyak field input tidak ter-crawl otomatis.
#
# Usage: ./03_param_discovery.sh <live_hosts_file> <output_dir> <threads>

set -euo pipefail

LIVE_HOSTS="$1"
OUTDIR="$2"
THREADS="${3:-20}"
mkdir -p "$OUTDIR"

# Timeout per-host (detik). Arjun tidak selalu punya timeout internal yang
# konsisten untuk host yang lambat/tidak respons, jadi kita bungkus manual
# supaya SATU host bermasalah tidak menahan seluruh batch.
PARAM_TIMEOUT="${PARAM_TIMEOUT:-60}"

> "$OUTDIR/hidden_params.txt"

echo "[*] Menjalankan Arjun per endpoint (timeout ${PARAM_TIMEOUT}s/host, paralel ${THREADS})..."

run_arjun() {
    local url="$1"
    local tmpfile
    tmpfile=$(mktemp)
    timeout "$PARAM_TIMEOUT" arjun -u "$url" -m GET,POST,JSON -t 10 --stable \
        -oT "$tmpfile" --rate-limit 5 2>/dev/null
    if [[ -s "$tmpfile" ]]; then
        cat "$tmpfile" >> "$OUTDIR/hidden_params.txt"
    fi
    rm -f "$tmpfile"
}
export -f run_arjun
export OUTDIR PARAM_TIMEOUT

# "|| true" penting di sini: xargs pulang dengan exit code 123 kalau ADA SAJA
# satu invocation yang gagal/timeout (wajar untuk host yang lambat/down).
# Tanpa "|| true", set -e akan menghentikan seluruh stage ini padahal
# host lain sudah berhasil diproses.
cat "$LIVE_HOSTS" | xargs -P "$THREADS" -I{} bash -c 'run_arjun "$@"' _ {} || true

TOTAL=$(wc -l < "$OUTDIR/hidden_params.txt" 2>/dev/null || echo 0)
echo "[✓] $TOTAL parameter tersembunyi ditemukan → $OUTDIR/hidden_params.txt"
echo "[i] Catatan: hasil ini dipakai python/stored_xss_hunter.py untuk uji stored XSS"
