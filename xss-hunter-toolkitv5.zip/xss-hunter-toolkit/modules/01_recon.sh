#!/usr/bin/env bash
# 01_recon.sh — subdomain enumeration + live host detection
#
# Usage: ./01_recon.sh <domain> <output_dir>

set -euo pipefail

DOMAIN="$1"
OUTDIR="$2"
mkdir -p "$OUTDIR"

RECON_TIMEOUT="${RECON_TIMEOUT:-600}"

echo "[*] Subdomain enumeration untuk $DOMAIN ... (timeout ${RECON_TIMEOUT}s)"
rc=0
timeout "$RECON_TIMEOUT" subfinder -d "$DOMAIN" -silent -all > "$OUTDIR/subdomains_raw.txt" || rc=$?
[[ $rc -eq 124 ]] && echo "[!] subfinder timeout setelah ${RECON_TIMEOUT}s, lanjut dengan hasil parsial"

# Selalu masukkan domain utama juga
echo "$DOMAIN" >> "$OUTDIR/subdomains_raw.txt"
sort -u "$OUTDIR/subdomains_raw.txt" -o "$OUTDIR/subdomains.txt"

TOTAL=$(wc -l < "$OUTDIR/subdomains.txt")
echo "[✓] Ditemukan $TOTAL subdomain unik"

echo "[*] Mengecek host yang live... (timeout ${RECON_TIMEOUT}s)"
rc=0
timeout "$RECON_TIMEOUT" bash -c "cat '$OUTDIR/subdomains.txt' | httpx -silent -follow-redirects -title -status-code -tech-detect -o '$OUTDIR/live_hosts_full.txt'" || rc=$?
[[ $rc -eq 124 ]] && echo "[!] httpx timeout setelah ${RECON_TIMEOUT}s, lanjut dengan hasil parsial"

# Simpan versi bersih (URL saja) untuk dipakai tahap berikutnya
# (touch dulu jaga-jaga kalau httpx kena timeout sebelum sempat buat filenya)
touch "$OUTDIR/live_hosts_full.txt"
cat "$OUTDIR/live_hosts_full.txt" | awk '{print $1}' > "$OUTDIR/live_hosts.txt"

LIVE=$(wc -l < "$OUTDIR/live_hosts.txt")
echo "[✓] $LIVE host live dari $TOTAL subdomain → $OUTDIR/live_hosts.txt"
