#!/usr/bin/env bash
# 05_reflected_scan.sh — deteksi & scan reflected XSS
#
# Usage: ./05_reflected_scan.sh <candidates_file> <output_dir> <threads>

set -euo pipefail

CANDIDATES="$1"
OUTDIR="$2"
THREADS="${3:-20}"
mkdir -p "$OUTDIR"

# Timeout keseluruhan proses (detik) dan timeout per-request dalfox (detik).
# Kalau target pakai WAF/bot-protection (Cloudflare dsb), tiap request bisa
# lambat/di-retry — batas ini mencegah scan menggantung tanpa kepastian.
# Sesuaikan lewat env var kalau perlu, mis:
#   SCAN_TIMEOUT=3600 REQUEST_TIMEOUT=15 ./run_pipeline.sh
SCAN_TIMEOUT="${SCAN_TIMEOUT:-1800}"
REQUEST_TIMEOUT="${REQUEST_TIMEOUT:-10}"

echo "[*] [1/2] kxss — quick reflection check..."
if command -v kxss &> /dev/null; then
    cat "$CANDIDATES" | kxss > "$OUTDIR/reflected_raw.txt" 2>/dev/null || true
    REFLECTED=$(wc -l < "$OUTDIR/reflected_raw.txt" 2>/dev/null || echo 0)
    echo "[✓] $REFLECTED parameter menunjukkan reflection"
else
    echo "[!] kxss tidak ditemukan, lanjut langsung ke dalfox"
    cp "$CANDIDATES" "$OUTDIR/reflected_raw.txt"
fi

echo "[*] [2/2] dalfox — full reflected XSS scan (pipe mode)..."
echo "    timeout total ${SCAN_TIMEOUT}s, per-request ${REQUEST_TIMEOUT}s, ${THREADS} worker"
echo "    (progress dicetak live — kalau layar diam lama, kemungkinan kena WAF/rate-limit)"
rc=0
timeout "$SCAN_TIMEOUT" bash -c "
    cat '$CANDIDATES' | dalfox pipe \
        --skip-bav \
        --worker '$THREADS' \
        --timeout '$REQUEST_TIMEOUT' \
        --format json \
        -o '$OUTDIR/dalfox_reflected.json'
" || rc=$?

if [[ $rc -eq 124 ]]; then
    echo "[!] dalfox timeout setelah ${SCAN_TIMEOUT}s — cek hasil parsial di $OUTDIR/dalfox_reflected.json"
    echo "    Kalau sering timeout, kemungkinan target pakai bot-protection (Cloudflare dll)."
    echo "    Coba turunkan THREADS di config.yaml atau naikkan REQUEST_TIMEOUT."
elif [[ $rc -ne 0 ]]; then
    echo "[!] dalfox keluar dengan kode error $rc — cek log di atas"
fi

echo "[✓] Hasil reflected XSS lengkap → $OUTDIR/dalfox_reflected.json"
