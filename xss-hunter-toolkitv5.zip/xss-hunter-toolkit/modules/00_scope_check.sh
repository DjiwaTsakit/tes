#!/usr/bin/env bash
# 00_scope_check.sh — wrapper tipis ke python/scope_filter.py
#
# CATATAN PENTING: versi awal skrip ini pakai loop bash (`while read` + sed/cut
# per baris) yang sangat lambat untuk dataset besar — untuk puluhan ribu baris
# bisa memakan waktu berjam-jam karena tiap baris memicu beberapa kali fork
# subprocess. Sudah diganti total ke Python (python/scope_filter.py) yang
# meng-compile regex sekali di awal dan cache hasil per-host, sehingga 50rb+
# URL selesai dalam hitungan detik. Signature/argumen tetap sama supaya
# run_pipeline.sh tidak perlu diubah.
#
# Usage: ./00_scope_check.sh <input_file> <scope_file> <output_file>

set -euo pipefail

INPUT_FILE="$1"
SCOPE_FILE="$2"
OUTPUT_FILE="$3"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PYTHON_SCRIPT="$SCRIPT_DIR/../python/scope_filter.py"

if [[ ! -f "$SCOPE_FILE" ]]; then
    echo "[!] scope.txt tidak ditemukan: $SCOPE_FILE"
    exit 1
fi

if [[ ! -f "$PYTHON_SCRIPT" ]]; then
    echo "[!] python/scope_filter.py tidak ditemukan di $PYTHON_SCRIPT"
    exit 1
fi

python3 "$PYTHON_SCRIPT" "$INPUT_FILE" "$SCOPE_FILE" "$OUTPUT_FILE"
