#!/usr/bin/env bash
# 06_dom_scan.sh — deteksi DOM-based XSS
#
# Usage: ./06_dom_scan.sh <candidates_file> <output_dir> <threads>

set -euo pipefail

CANDIDATES="$1"
OUTDIR="$2"
THREADS="${3:-20}"
mkdir -p "$OUTDIR"

SCAN_TIMEOUT="${SCAN_TIMEOUT:-1800}"
REQUEST_TIMEOUT="${REQUEST_TIMEOUT:-10}"

echo "[*] dalfox — DOM XSS scan (headless-based deep scan)..."
echo "    timeout total ${SCAN_TIMEOUT}s, per-request ${REQUEST_TIMEOUT}s, ${THREADS} worker"
rc=0
timeout "$SCAN_TIMEOUT" bash -c "
    cat '$CANDIDATES' | dalfox pipe \
        --deep-domxss \
        --worker '$THREADS' \
        --timeout '$REQUEST_TIMEOUT' \
        --format json \
        -o '$OUTDIR/dalfox_dom.json'
" || rc=$?

if [[ $rc -eq 124 ]]; then
    echo "[!] dalfox DOM scan timeout setelah ${SCAN_TIMEOUT}s — cek hasil parsial"
elif [[ $rc -ne 0 ]]; then
    echo "[!] dalfox keluar dengan kode error $rc — cek log di atas"
fi

echo "[✓] Hasil DOM XSS → $OUTDIR/dalfox_dom.json"
echo "[i] Untuk analisa sink JS lebih detail (innerHTML, eval, document.write),"
echo "    hasil file JS dari katana bisa diperiksa manual dengan LinkFinder/SecretFinder"
