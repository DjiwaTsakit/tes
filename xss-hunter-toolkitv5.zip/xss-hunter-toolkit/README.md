# XSS Hunter Toolkit

Automation pipeline untuk pencarian XSS (Reflected, Stored, DOM-based, Blind)
yang menggabungkan tools recon/crawling populer dengan lapisan verifikasi
headless browser untuk mengurangi false positive.

## ⚠️ DISCLAIMER — WAJIB DIBACA

Toolkit ini **hanya boleh digunakan** terhadap target yang:
1. Memiliki program bug bounty resmi dengan scope yang jelas, ATAU
2. Aset milik Anda sendiri / yang Anda punya izin tertulis untuk diuji.

Setiap request otomatis di pipeline ini akan **dicek dulu terhadap `scope.txt`**
sebelum dieksekusi (lihat `modules/00_scope_check.sh`). Jangan hapus/lewati
pengecekan ini. Melanggar scope program bug bounty bisa berujung ban akun
platform (HackerOne/Bugcrowd/Intigriti) bahkan tuntutan hukum.

Toolkit ini TIDAK melakukan exploitation lanjutan (session hijacking, cookie
stealing ke server pihak lain, dsb) — hanya deteksi & bukti eksekusi payload
non-destruktif (alert/marker DOM), sesuai standar proof-of-concept bug bounty.

## Arsitektur Pipeline

```
00_scope_check.sh   → filter semua domain sesuai scope.txt
01_recon.sh         → subfinder + httpx (live hosts)
02_crawl.sh         → katana + gau + waybackurls + gospider (URL collection)
03_param_discovery.sh → Arjun (hidden parameter discovery)
04_filter_candidates.sh → gf 'xss' + qsreplace (kandidat parameter)
05_reflected_scan.sh → kxss + dalfox (reflected XSS)
06_dom_scan.sh       → dalfox --deep-domxss (DOM XSS)

python/blind_inject.py       → inject payload blind XSS (Interactsh) ke semua
                                 parameter & header, untuk stored/blind XSS
                                 yang baru "meledak" nanti (admin panel dsb)
python/stored_xss_hunter.py  → submit payload ke form, revisit halaman output,
                                 pakai Playwright untuk cek marker
python/verify_execution.py   → headless verification: buka ulang semua kandidat,
                                 konfirmasi eksekusi nyata (dialog event / DOM
                                 mutation), screenshot sebagai bukti
python/report_generate.py    → gabungkan semua hasil jadi 1 laporan HTML
```

## Environment Variable untuk Timeout (penting untuk target besar)

Setiap tool eksternal dibungkus `timeout` supaya pipeline **tidak pernah
menggantung tanpa batas**. Kalau target punya banyak subdomain/URL (seperti
aset besar semacam `assets.digitalocean.com`), naikkan nilainya:

```bash
export RECON_TIMEOUT=900      # subfinder + httpx, default 600s
export CRAWL_TIMEOUT=1800     # katana/gau/waybackurls/gospider, default 600s per tool
export PARAM_TIMEOUT=90       # Arjun per host, default 60s
export SCAN_TIMEOUT=3600      # dalfox total per stage, default 1800s
export REQUEST_TIMEOUT=15     # dalfox per-request, default 10s

./run_pipeline.sh
```

Kalau salah satu tool kena timeout, pipeline **tetap lanjut** dengan hasil
parsial (bukan berhenti total) — akan ada pesan `[!] ... timeout setelah Xs`
di log supaya kamu tahu tahap mana yang datanya mungkin tidak lengkap.

## Kenapa URL bisa sangat banyak (puluhan ribu)?

`gau`/`waybackurls` menarik data historis dari Wayback Machine, CommonCrawl,
dst — untuk domain besar ini bisa menghasilkan puluhan ribu URL. Dua sumber
noise terbesar sudah difilter otomatis di `modules/02_crawl.sh` **sebelum**
masuk ke tahap dedup/filtering/scan:

**1. File statis** — tidak pernah jadi vektor XSS, dikelompokkan per kategori
(mudah ditambah/dikurangi langsung di variabel `STATIC_EXT_REGEX`):

| Kategori | Ekstensi |
|---|---|
| Gambar | jpg/jpeg, png, gif, bmp, ico, svg, webp, tiff/tif, heic, heif, avif |
| Design/vector | ai, psd, eps, sketch, fig, indd, xd |
| Font | woff/woff2, ttf, eot, otf |
| Dokumen | pdf, doc/docx, xls/xlsx, ppt/pptx, odt, ods, odp, rtf, csv |
| Arsip | zip, rar, 7z, tar, gz, tgz, bz2, xz, iso |
| Installer/binary | dmg, pkg, deb, rpm, msi, exe, apk, jar, war |
| Media | mp3, mp4, avi, mov, wmv, flv, webm, wav, ogg, m4a, flac, mkv, 3gp |
| Lain-lain | swf, torrent, ics, vcf, class, dll, so, map, scss, sass, less |

`.js`, `.json`, `.xml`, `.css`, `.php`, `.asp`, `.jsp` dan sejenisnya **sengaja
tidak difilter** karena itu justru target utama pencarian XSS (terutama `.js`
untuk analisa DOM sink).

**2. Domain di luar scope** — `02_crawl.sh` sekarang menerima `scope_file`
sebagai argumen ke-4 dan langsung memfilter berdasarkan `scope.txt` **di
sumbernya**, bukan hardcode daftar "google.com, facebook.com, dst" (rapuh,
gampang ada yang lolos). Ini penting karena `gospider` ikut mengekstrak semua
link yang ada di halaman — termasuk share button Facebook, Google Fonts, CDN
pihak ketiga (jsdelivr, cloudflare cdnjs), dsb — yang otomatis ikut ter-scrape
walau jelas di luar scope program bug bounty.

`run_pipeline.sh` otomatis mengoper `scope.txt` ke tahap ini. Stage 2b (scope
check terpisah setelah crawl) tetap dipertahankan sebagai **safety net kedua**
— murah karena sudah pakai Python cepat, jaga-jaga ada yang lolos dari filter
pertama (mis. dari redirect).

Scope-check sendiri sudah ditulis ulang pakai Python (`python/scope_filter.py`)
dengan regex ter-compile sekali + cache per-host, jadi 50.000+ URL selesai
dalam hitungan detik, bukan jam.


## Prasyarat Tools (install manual / via install.sh)

| Tool | Fungsi |
|---|---|
| subfinder, httpx, katana | ProjectDiscovery suite (recon & crawl) |
| gau, waybackurls | Historical URL collection |
| gospider | Crawler tambahan |
| Arjun | Hidden parameter discovery |
| gf (+ pattern xss) | URL/parameter filtering |
| qsreplace, uro | Query string manipulation & dedup |
| kxss | Reflection checker cepat |
| dalfox | Scanner XSS utama (reflected + DOM) |
| Python 3.10+, Playwright | Verifikasi headless & stored XSS |
| interactsh-client (opsional) | Callback server untuk blind XSS |

Jalankan `./install.sh` untuk mencoba instalasi otomatis (butuh Go & internet
di mesin Anda — sandbox ini tidak punya akses ke domain-domain tersebut).

## Cara Pakai

```bash
cp config.example.yaml config.yaml
# edit config.yaml: isi domain target & path scope.txt

echo "*.target.com" > scope.txt   # sesuaikan dengan scope program bug bounty

./run_pipeline.sh
```

Hasil akhir ada di `output/report.html`.
