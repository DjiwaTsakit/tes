#!/usr/bin/env bash
# 02_crawl.sh — deep URL collection (aktif + pasif/historical)
#
# Usage: ./02_crawl.sh <live_hosts_file> <output_dir> <threads>

set -euo pipefail

LIVE_HOSTS="$1"
OUTDIR="$2"
THREADS="${3:-20}"
mkdir -p "$OUTDIR"

# Timeout per tool (detik) supaya pipeline tidak pernah menggantung tanpa
# batas kalau salah satu provider (CDX API archive.org, dsb) lambat/hang.
# Sesuaikan lewat env var kalau target punya history sangat besar, mis:
#   CRAWL_TIMEOUT=1800 ./run_pipeline.sh
CRAWL_TIMEOUT="${CRAWL_TIMEOUT:-600}"

# Catatan: pola "cmd || rc=$?" dipakai (bukan "cmd; rc=$?") karena di bawah
# set -e, kalau cmd exit non-zero (mis. kena timeout/124) shell akan langsung
# keluar SEBELUM baris "rc=$?" sempat jalan. Dengan "|| rc=$?", exit code
# non-zero dari cmd "ditangkap" oleh operator || sehingga set -e tidak trigger.

echo "[*] [1/4] Katana — active crawling (JS-aware)... (timeout ${CRAWL_TIMEOUT}s)"
rc=0
timeout "$CRAWL_TIMEOUT" katana -list "$LIVE_HOSTS" -jc -kf all -c "$THREADS" -d 3 -silent \
    -o "$OUTDIR/urls_katana.txt" || rc=$?
[[ $rc -eq 124 ]] && echo "[!] katana timeout setelah ${CRAWL_TIMEOUT}s, lanjut dengan hasil parsial"

echo "[*] [2/4] gau — historical URLs (Wayback, CommonCrawl, OTX, URLScan)... (timeout ${CRAWL_TIMEOUT}s)"
rc=0
cat "$LIVE_HOSTS" | sed 's#https\?://##' | cut -d'/' -f1 | sort -u | \
    timeout "$CRAWL_TIMEOUT" gau --threads "$THREADS" --subs > "$OUTDIR/urls_gau.txt" || rc=$?
[[ $rc -eq 124 ]] && echo "[!] gau timeout setelah ${CRAWL_TIMEOUT}s, lanjut dengan hasil parsial"

echo "[*] [3/4] waybackurls — Wayback Machine tambahan... (timeout ${CRAWL_TIMEOUT}s)"
rc=0
cat "$LIVE_HOSTS" | sed 's#https\?://##' | cut -d'/' -f1 | sort -u | \
    timeout "$CRAWL_TIMEOUT" waybackurls > "$OUTDIR/urls_wayback.txt" || rc=$?
[[ $rc -eq 124 ]] && echo "[!] waybackurls timeout setelah ${CRAWL_TIMEOUT}s, lanjut dengan hasil parsial"

echo "[*] [4/4] gospider — crawler tambahan untuk cakupan lebih dalam... (timeout ${CRAWL_TIMEOUT}s)"
rc=0
timeout "$CRAWL_TIMEOUT" gospider -S "$LIVE_HOSTS" -c "$THREADS" -d 2 --other-source -q \
    -o "$OUTDIR/gospider_raw" || rc=$?
[[ $rc -eq 124 ]] && echo "[!] gospider timeout setelah ${CRAWL_TIMEOUT}s, lanjut dengan hasil parsial"
find "$OUTDIR/gospider_raw" -type f -exec cat {} \; 2>/dev/null | \
    grep -oE 'https?://[^ ]+' > "$OUTDIR/urls_gospider.txt" || true

echo "[*] Menggabungkan & dedup semua URL..."
cat "$OUTDIR"/urls_*.txt 2>/dev/null | sort -u > "$OUTDIR/all_urls_raw.txt"

# uro membersihkan URL yang secara fungsional duplikat (mis. beda value param
# tapi struktur sama) supaya scan lebih efisien
if command -v uro &> /dev/null; then
    cat "$OUTDIR/all_urls_raw.txt" | uro > "$OUTDIR/all_urls.txt"
else
    cp "$OUTDIR/all_urls_raw.txt" "$OUTDIR/all_urls.txt"
fi

TOTAL=$(wc -l < "$OUTDIR/all_urls.txt")
echo "[✓] Total $TOTAL URL unik terkumpul → $OUTDIR/all_urls.txt"
